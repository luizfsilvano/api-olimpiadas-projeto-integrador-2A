from django.apps import AppConfig


class OlimpiadasappConfig(AppConfig):
    name = 'OlimpiadasApp'
